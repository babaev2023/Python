import setuptools

setuptools.setup(
    name='language',
    packages=['language'],
    python_requires='>=2.7',
)
